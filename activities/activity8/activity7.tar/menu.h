/*
 * menu.h
*/

const char *menuHeader = 
                         "=======================\n"
						 "This is the menu header\n"
                         "=======================";


