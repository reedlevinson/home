#include <stdio.h>
#include "meal.h"

static const char mealHeader[] = "This is the header for a meal";

void showMealHeader()
{
	puts(mealHeader);
}

