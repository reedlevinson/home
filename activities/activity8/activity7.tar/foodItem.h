/*
 * foodItem.h
*/

 
void showFoodItemHeader();
