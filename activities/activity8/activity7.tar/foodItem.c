#include <stdio.h>
#include "foodItem.h"

static const char* foodItemHeader = "This is the header for a foodItem";

void showFoodItemHeader()
{
	puts(foodItemHeader);

}

